#!/bin/bash
echo "▶ Flask 서버 시작 준비 중..."
python main.py
